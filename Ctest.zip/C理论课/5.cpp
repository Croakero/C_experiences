#include<stdio.h>
int main(void){
	int y,m,d,sum;
	int tot,m31,m30;
	scanf("%d %d %d",&y,&m,&d);
	int a1[7]{1,3,5,7,8,10,12};
	int a2[4]{4,6,9,11};
}
	
